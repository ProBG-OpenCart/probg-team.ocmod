<?php
$_['heading_title']='Team Members';$_['text_success']='Success: Member saved!';$_['text_list']='Members';$_['text_add']='Add member';$_['text_edit']='Edit member';$_['text_enabled']='Enabled';$_['text_disabled']='Disabled';$_['text_home']='Home';$_['text_no_results']='No results!';$_['text_pagination']='Showing %d to %d of %d (%d Pages)';$_['column_name']='Title';$_['column_category']='Category';$_['column_sort_order']='Sort order';$_['column_status']='Status';$_['column_action']='Action';$_['entry_name']='Title';$_['entry_category']='Category';$_['entry_short_description']='Short description';$_['entry_description']='Description';$_['entry_image']='Image';$_['entry_additional_images']='Additional images';$_['entry_telephone']='Telephone';$_['entry_city']='City';$_['entry_website']='Website';$_['entry_facebook']='Facebook';$_['entry_instagram']='Instagram';$_['entry_youtube']='YouTube';$_['entry_linkedin']='LinkedIn';$_['entry_meta_title']='Meta title';$_['entry_meta_description']='Meta description';$_['entry_meta_keyword']='Meta keywords';$_['entry_seo_url']='SEO URL';$_['entry_sort_order']='Sort order';$_['entry_status']='Status';$_['button_add']='Add';$_['button_edit']='Edit';$_['button_delete']='Delete';$_['button_save']='Save';$_['button_cancel']='Cancel';$_['button_filter']='Filter';$_['error_permission']='Warning: No permission!';$_['error_name']='Title must be between 1 and 255 characters!';$_['error_category']='Select a category!';$_['error_seo_url']='SEO URL is already in use!';
$_['error_seo_url_format']='SEO URL must be one path segment containing only letters, numbers, hyphens or underscores!';
$_['help_seo_url']='Leave empty to generate it automatically as ID-title, for example 18-john-smith. Do not include the category, section or slashes.';
$_['entry_working_hours']='Working hours';
$_['help_working_hours']='Enter working hours as text. You may use a separate line for each day.';

$_['entry_id']='ID';$_['column_id']='ID';$_['column_image']='Image';$_['column_city']='City';$_['column_date_modified']='Modified';$_['button_clear']='Clear';
$_['tab_general']='Content'; $_['tab_seo']='SEO URL'; $_['tab_images']='Images'; $_['tab_data']='Data'; $_['button_view']='View';
$_['text_confirm']='Are you sure?';
// v0.7.0
$_['tab_stores']='Stores'; $_['entry_store']='Show in stores'; $_['help_store']='The member is visible only in the selected stores. Each selected store must also be enabled for the category.'; $_['error_store']='Select at least one store!'; $_['error_store_category']='The member cannot be shown in a store that is not enabled for its category.';

// v0.9.1 admin navigation
$_['tab_settings']='Settings'; $_['tab_categories']='Categories'; $_['tab_members']='Members'; $_['text_all']='All';
// v1.0.0-beta.2 Blog architecture alignment
$_['text_team']='ProBG Team'; $_['text_automatic']='Automatic'; $_['column_date_added']='Added'; $_['entry_date_added']='Date added'; $_['entry_date_modified']='Date modified';
$_['help_category_layout']='The member profile uses the Layout configured for the selected category and active store.';
