<?php
$_['heading_title']='Членове на екипа';$_['text_success']='Членът е записан успешно!';$_['text_list']='Членове';$_['text_add']='Добавяне на член';$_['text_edit']='Редакция на член';$_['text_enabled']='Включено';$_['text_disabled']='Изключено';$_['text_home']='Начало';$_['text_no_results']='Няма резултати!';$_['text_pagination']='Показани %d до %d от %d (%d страници)';$_['column_name']='Заглавие';$_['column_category']='Категория';$_['column_sort_order']='Подредба';$_['column_status']='Статус';$_['column_action']='Действие';$_['entry_name']='Заглавие';$_['entry_category']='Категория';$_['entry_short_description']='Кратко описание';$_['entry_description']='Описание';$_['entry_image']='Изображение';$_['entry_additional_images']='Допълнителни изображения';$_['entry_telephone']='Телефон';$_['entry_city']='Град';$_['entry_website']='Собствен сайт';$_['entry_facebook']='Facebook';$_['entry_instagram']='Instagram';$_['entry_youtube']='YouTube';$_['entry_linkedin']='LinkedIn';$_['entry_meta_title']='Мета заглавие';$_['entry_meta_description']='Мета описание';$_['entry_meta_keyword']='Мета ключови думи';$_['entry_seo_url']='SEO URL';$_['entry_sort_order']='Подредба';$_['entry_status']='Статус';$_['button_add']='Добави';$_['button_edit']='Редакция';$_['button_delete']='Изтрий';$_['button_save']='Запази';$_['button_cancel']='Отказ';$_['button_filter']='Филтрирай';$_['error_permission']='Нямате права за промяна на членовете!';$_['error_name']='Заглавието трябва да бъде между 1 и 255 символа!';$_['error_category']='Изберете категория!';$_['error_seo_url']='SEO URL вече се използва!';
$_['error_seo_url_format']='SEO URL трябва да бъде един адресен сегмент и да съдържа само букви, цифри, тире или долна черта!';
$_['help_seo_url']='Оставете празно за автоматично генериране във формат ID-заглавие, например 18-ivan-ivanov. Не добавяйте категорията, секцията или наклонени черти.';
$_['entry_working_hours']='Работно време';
$_['help_working_hours']='Въведете работното време като текст. Може да използвате отделен ред за всеки ден.';

$_['entry_id']='ID';$_['column_id']='ID';$_['column_image']='Изображение';$_['column_city']='Град';$_['column_date_modified']='Обновен';$_['button_clear']='Изчисти';
$_['tab_general']='Съдържание'; $_['tab_seo']='SEO URL'; $_['tab_images']='Изображения'; $_['tab_data']='Данни'; $_['button_view']='Преглед';
$_['text_confirm']='Сигурни ли сте?';
// v0.7.0
$_['tab_stores']='Магазини'; $_['entry_store']='Показване в магазини'; $_['help_store']='Членът ще бъде видим само в избраните магазини. Избраните магазини трябва да са разрешени и за категорията.'; $_['error_store']='Изберете поне един магазин!'; $_['error_store_category']='Членът не може да бъде показван в магазин, който не е избран за неговата категория.';

// v0.9.1 admin navigation
$_['tab_settings']='Настройки'; $_['tab_categories']='Категории'; $_['tab_members']='Членове'; $_['text_all']='Всички';
